# Dutch Auction

# How to run and bid:

1. Run Ganache
2. In contracts folder build & deploy contracts
3. Link Ganache to truffle-config.js
4. Update coin and auction addresses in script.js based on the deployed ones in ganache
5. Open index.html, place bid of like 1000 and provide account address as the bidder -> If no bid made, experiment with the amount... 